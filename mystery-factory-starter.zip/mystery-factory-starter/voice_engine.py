# Türkçe seslendirme motoru (V2 iskeleti)
