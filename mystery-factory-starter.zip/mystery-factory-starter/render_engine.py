# Render motoru (V2 iskeleti)
