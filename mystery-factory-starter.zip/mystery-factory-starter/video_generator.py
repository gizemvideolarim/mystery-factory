# Gemini video üretim motoru (V2 iskeleti)
