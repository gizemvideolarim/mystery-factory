# Altyazı motoru (V2 iskeleti)
