# Mystery Factory

İsimsiz Dosyalar için otomatik Shorts video üretim sistemi.

## Özellikler
- 15 video üretimi
- Türkçe seslendirme
- Otomatik altyazı
- 1080x1920 Shorts render
- Thumbnail üretimi
- Toplu video işleme
