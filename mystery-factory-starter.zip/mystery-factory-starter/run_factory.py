from pathlib import Path

print("Mystery Factory V2 başlangıç paketi hazır.")
Path("factory_output").mkdir(exist_ok=True)
Path("videos").mkdir(exist_ok=True)
